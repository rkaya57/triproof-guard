# ScamGuard Web3 Shield Chrome Extension

Pre-sign protection for Solana and EVM dApps, airdrops, token claims, and suspicious wallet actions.

## Protection features

- Popup current-tab URL scanner.
- Page banner with live URL risk status.
- Page link scanner for visible links.
- Injected Solana provider pre-sign observer for:
  - `signTransaction`
  - `signAndSendTransaction`
  - `signAllTransactions`
  - generic signing `provider.request(...)` calls
- Plain-language signing review for every intercepted wallet request, including approvals, transfers, authority changes, account closure, mint actions, and message signatures.
- A short decision timeline that shows source context, decoded intent, evidence, and the final risk decision.
- Local scan history for the latest 100 site and wallet checks. History stores a redacted target and decision summary only.
- Shareable, privacy-preserving report snapshots that omit raw wallet payloads, public keys, and URL query parameters.
- Injected EVM provider pre-sign observer for MetaMask/Rabby/Coinbase style:
  - `eth_sendTransaction`
  - `personal_sign`
  - `eth_sign`
  - `eth_signTypedData_v4`
  - `wallet_switchEthereumChain`
- Local settings:
  - API base URL
  - warn on caution-level signing
  - block critical pages with overlay
  - trusted domains

## Local install

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select this folder:

```text
chrome-extension
```

## Default API

The extension uses:

```text
https://triproofprotocol.com
```

Public scanner endpoint used by the popup and content script:

```text
POST /api/scamguard/scan-url
POST /api/scamguard/scan-transaction
```

## Privacy boundary

- The extension never asks for seed phrases, private keys, or mnemonics.
- It only reads page URLs, page links, and transaction payloads that the dApp asks the wallet provider to sign.
- It does not read wallet extension internal pages.
- Transaction payloads are sent to the configured ScamGuard API for risk analysis.
- The connected wallet public key may be sent as context when available.
- Local history and shared reports never include raw transaction payloads, seed phrases, private keys, or query parameters.

## Validation

From the repo root:

```bash
npm run extension:validate
```
